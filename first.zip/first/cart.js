document.addEventListener("DOMContentLoaded", () => {
    const cartItemsContainer = document.getElementById("cart-items");
    const cart = JSON.parse(localStorage.getItem("cart")) || [];
  
    if (cart.length === 0) {
      cartItemsContainer.innerHTML = "<p>your shopping cart is empty</p>";
      return;
    }
  
    cart.forEach((item, index) => {
      const itemDiv = document.createElement("div");
      itemDiv.classList.add("cart-item");
      itemDiv.innerHTML = `
        <img src="${item.image}" alt="${item.name}" />
        <div>
          <p>${item.name}</p>
          <p>price ${item.price}$</p>
          <div>
            <button class="decrease" data-index="${index}">-</button>
            <span>${item.quantity}</span>
            <button class="increase" data-index="${index}">+</button>
            <button class="remove" data-index="${index}">×</button>
          </div>
        </div>
     ` ;
      cartItemsContainer.appendChild(itemDiv);
    });
  
    // دکمه‌ها
    cartItemsContainer.addEventListener("click", (e) => {
      const index = parseInt(e.target.dataset.index);
      if (e.target.classList.contains("increase")) {
        cart[index].quantity++;
      } else if (e.target.classList.contains("decrease")) {
        cart[index].quantity = Math.max(1, cart[index].quantity - 1);
      } else if (e.target.classList.contains("remove")) {
        cart.splice(index, 1);
      }
      localStorage.setItem("cart", JSON.stringify(cart));
      location.reload();
    });
    
  });
  const cart = JSON.parse(localStorage.getItem("cart")) || [];
const container = document.getElementById("cart-items");

let total = 0;

cart.forEach((item, index) => {
    // محاسبه قیمت آیتم
    const itemTotal = parseFloat(item.price.replace("$", "")) * item.quantity;
    total += itemTotal;

    // اضافه کردن آیتم به HTML
    container.innerHTML += `
        <div style="margin-bottom: 10px;">
            <p><strong>${item.name}</strong></p>
            <p>قیمت: ${item.price}</p>
            <p>تعداد: ${item.quantity}</p>
            <p>جمع کل: ${itemTotal.toFixed(2)}$</p>
            <hr>
        </div>`
    ;
});

// اضافه کردن Total به آخر صفحه
container.innerHTML += <div style="margin-top: 20px; font-weight: bold;">جمع کل خرید: ${total.toFixed(2)}$</div>;