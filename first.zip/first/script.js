document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById("contact-form");

    form.addEventListener("submit", function (event) {
        event.preventDefault();
        alert("Your message successfully sent");
        form.reset();
    });

    const slides = document.querySelector(".slides");
    const images = document.querySelectorAll(".slides img");
    const prevBtn = document.querySelector(".prev");
    const nextBtn = document.querySelector(".next");
    const sliderContainer = document.querySelector(".slider"); // عنصر اصلی اسلایدر

    let currentIndex = 0;

    function updateSlidePosition() {
        const width = images[0].clientWidth;
        slides.style.transform = `translateX(-${currentIndex * width}px)`;
    }

    nextBtn.addEventListener("click", function () {
        currentIndex = (currentIndex + 1) % images.length;
        updateSlidePosition();
    });

    prevBtn.addEventListener("click", function () {
        currentIndex = (currentIndex - 1 + images.length) % images.length;
        updateSlidePosition();
    });

    // اسلاید خودکار
    let autoSlide = setInterval(() => {
        currentIndex = (currentIndex + 1) % images.length;
        updateSlidePosition();
    }, 2000);

    // توقف هنگام ورود ماوس
    sliderContainer.addEventListener("mouseenter", () => {
        clearInterval(autoSlide);
    });

    // ادامه حرکت پس از خروج ماوس
    sliderContainer.addEventListener("mouseleave", () => {
        autoSlide = setInterval(() => {
            currentIndex = (currentIndex + 1) % images.length;
            updateSlidePosition();
        }, 2000);
    });
    const cartItems=[];
    const cartCountEl=
    document.getElementById("cart-count");
    const itemCartIcons=document.querySelectorAll(".item-cart-icon");
    itemCartIcons.forEach((icon,index)=>{
        icon.addEventListener("click",()=>{
            const productItem=icon.closest(".product-item");
            const name=productItem.querySelector("p").textContent;
            const price=productItem.querySelector("span").textContent;
            const image=productItem.querySelector("img").src;
            const product={name,price,image}
            addToCart(product);
            const cart=JSON.parse(localStorage.getItem("cart"))||[];
            cartCountEl.textContent=cart.reduce((acc,item)=>acc+item.quantity,0);
            cartItems.push({name,price});
            cartCountEl.textContent=cartItems.length;
        });
    });

    window.addEventListener("resize", updateSlidePosition);
    updateSlidePosition();
    function addToCart(product) {
        let cart = JSON.parse(localStorage.getItem("cart")) || [];
        const existingItem = cart.find(item => item.name === product.name);
      
        if (existingItem) {
          existingItem.quantity++;
        } else {
          product.quantity = 1;
          cart.push(product);
        }
      
        localStorage.setItem("cart", JSON.stringify(cart));
      }
});